/*
 Klasa HighArray jest teraz opakowana dookoła tablicy. W procedurze main(), tworzymy tablicę tej klasy i dokonujemy prawie tych samych operacji jak w programie lowArray.java: wstawiamy 10 elementów, szukamy elementu (którego tam nie ma) i wyświetlamy tablicę. Ponieważ to jest takie łatwe, usuwamy trzy elementy (0, 55, and 99) zamiast jednego i ostatecznie  znów wyświetlamy tablicę:

77 99 44 55 22 88 11 0 66 33
Can't find 35
77 44 22 88 11 66 33

Proszę zauważyć jak krótka i prosta jest metoda main(). Szczegóły, które musiały być zawarte w main() w lowArray.java  są teraz zapisane w metodach klasy HighArray.
W HighArray class, metoda  find() przegląda tablice szukając elementu którego indeks przekazano jej jako argument. Zwraca true lub false.
Metoda insert() umieszcza nowy element w dostępnym miejscu tablicy. Pole nElems przechowuje liczbę aktualnie wykorzystanych elementów tablicy.
Metoda delete() szuka elementu, którego indeks dostała jako argument i gdy go znajdzie przesuwa wszystkie elementy o wyższych indeksach w dół – nadpisując go -  oraz  zmniejsza wartość w polu nElems. Metoda display() wyświetla tablicę.
W lowArray.java, kod w  main() dla znajdowania elementu ma osiem linii, w 
highArray.java, tylko jedną. Użytkownik w HighArrayApp.class, nie musi myśleć o indeksach i innych szczególach tablicy. Właściwie nie musi w ogóle wiedzieć w jakiej strukturze danych informacje są przechowywane przez HighArray.class! Ta struktura jest ukryta za interfejsem. Ten mechanizm określamy jako abstrakcję.

Opis: Lafore 73
 */

package higharrayapp;

import java.io.*; // for I/O


class HighArray
{
private double[] a; // ref to array a
private int nElems; // number of data items
private double s=0;

public HighArray(int max) // konstruktor: metoda wywoływana zawsze w momencie
        //tworzenia obiektu w pamięci; nigdy nie zwaraca wyniku, musi mieć nazwę
        //taką samą jak klasa. Może mieć parametry
{
    a = new double[max]; // create the array
    nElems = 0; // no items yet
}

public boolean find(double searchKey)
{ // find specified value
int j;
for(j=0; j<nElems; j++) // for each element,
    if(a[j] == searchKey) // found item?
        break; // exit loop before end
if(j == nElems) // gone to end?
    return false; // yes, can't find it
else
    return true; // no, found it
} // end find()

public void insert(double value) // put element into array
{
    a[nElems] = value; // insert it
    nElems++; // increment size
}

public boolean delete(double value)
{
int j;
for(j=0; j<nElems; j++) // look for it
    if( value == a[j] )
        break;
if(j==nElems) // can't find it
    return false;
else // found it
{
    for(int k=j; k<nElems; k++) // move higher ones down
        a[k] = a[k+1];
    nElems--; // decrement size
    return true;
}
} // end delete()

public void display() // displays array contents
{
for(int j=0; j<nElems; j++) // for each element,
    System.out.print(a[j] + " "); // display it
System.out.println("");
}

} // end class HighArray


class HighArrayApp
{
public static void main(String[] args)
{
int maxSize = 100; // array size

//tworzymy obiekt klasy HighArray:
HighArray arr; // reference to array
arr = new HighArray(maxSize); // create the array

// insert 10 items
arr.insert(77); //wywołujemy metodę insert działającą na tablicty 'arr'
arr.insert(99);
arr.insert(44);
arr.insert(55);
arr.insert(22);
arr.insert(88);
arr.insert(11);
arr.insert(00);
arr.insert(66);
arr.insert(33);
arr.display(); // display items
int searchKey = 35; // search for item
if( arr.find(searchKey) )
    System.out.println("Found " + searchKey);
else
    System.out.println("Can't find " + searchKey);
arr.delete(00); // delete 3 items

//dodano
searchKey=56; //szukamy nieistniejacego aby skasować
arr.delete(56); if (!arr.delete(56)) System.out.println("nie ma ");
//arr.delete(56)==false
arr.delete(99);
arr.display(); // display items again


} // end main()
} // end class HighArrayApp
