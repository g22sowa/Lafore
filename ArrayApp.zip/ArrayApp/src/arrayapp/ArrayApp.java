/*
Co robi program: w nieuporządkowanej tablicy szuka elementu (searchKey = 66) i informuje, że go znalazł lub nie.
Następnie usuwa jeden element (searchKey = 55) z tablicy, zmniejszając licznik wskazujący na ilość elementów przechowywanych i przesuwając elementy większe w dół tablicy
Opis: Lafore str. 66
 */
package arrayapp;

import java.io.IOException;
import java.io.*; //nieużywany - wykorzystywany w innych przykł. w podręczniku

/**
 *
 * @author hp
 */
public class ArrayApp {

public static void main(String[] args) throws IOException
        
{
int[] arr; // reference
arr = new int[100]; // make array
int nElems = 0; // number of items
int j; // loop counter
int searchKey; // key of item to search for

arr[0] = 77; // insert 10 items
arr[1] = 99;
arr[2] = 44;
arr[3] = 55;
arr[4] = 22;
arr[5] = 88;
arr[6] = 11;
arr[7] = 00;
arr[8] = 66;
arr[9] = 33;
nElems = 10; // now 10 items in array

for(j=0; j<nElems; j++) // display items
    System.out.print(arr[j] + " ");
System.out.println("");

searchKey = 66; // find item with key 66
for(j=0; j<nElems; j++) // for each element,
    if(arr[j] == searchKey) // found item?
        break; // yes, exit before end
if(j == nElems) // at the end?
    System.out.println("Can't find " + searchKey); // yes
else
    System.out.println("Found " + searchKey); // no
//-------------------------------------------------------------
searchKey = 55; // delete item with key 55
for(j=0; j<nElems; j++) // look for it
    if(arr[j] == searchKey)
        break;
for(int k=j; k<nElems; k++) // move higher ones down
    arr[k] = arr[k+1];
nElems--; // decrement size

for(j=0; j<nElems; j++) // display items
    System.out.print( arr[j] + " ");
System.out.println("");
} // end main()
} // end class

  


